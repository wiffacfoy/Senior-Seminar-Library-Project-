﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Library
{
    public partial class AddBooks : Form
    {
        public AddBooks()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtBookName.Text != "" && txtAuthor.Text != "" && txtPublication.Text != "" && txtPrice.Text != "" && txtQuantity.Text != "")
            {
                String bname = txtBookName.Text;
                String bauthor = txtAuthor.Text;
                String bpublication = txtPublication.Text;
                String bdate = dateTimePicker1.Text;
                Int64 price = Int64.Parse(txtPrice.Text);
                Int64 quantity = Int64.Parse(txtQuantity.Text);



                string connStr = "server=localhost;user=root;database=sys;port=3306;password=Nicholas29!!";
                MySqlConnection conn = new MySqlConnection(connStr);

                conn.Open();

                string query = "INSERT INTO NewBook (bName, bAuthor, bPubl, bPDate, bPrice, bQuan) " +
                       "VALUES (@bname, @bauthor, @bpublication, @bdate, @price, @quantity)";

                using (MySqlConnection con = new MySqlConnection(connStr))
                {

                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }


                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);


                    cmd.Parameters.AddWithValue("@bname", bname);
                    cmd.Parameters.AddWithValue("@bauthor", bauthor);
                    cmd.Parameters.AddWithValue("@bpublication", bpublication);
                    cmd.Parameters.AddWithValue("@bdate", bdate);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@quantity", quantity);

                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Book inserted successfully.");

                    txtBookName.Clear();
                    txtAuthor.Clear();
                    txtPublication.Clear();
                    txtPrice.Clear();
                    txtQuantity.Clear();
                    dateTimePicker1.Value = DateTime.Now;
                }

            }

            else
            {
                MessageBox.Show("Please fill all fields.");
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to cancel?", "Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
